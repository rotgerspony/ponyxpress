
# ponyxpress_full_app.py with /scan and /uploads support

from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import os
from werkzeug.utils import secure_filename
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ponyxpress.db'
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(120))
    role = db.Column(db.String(20), default="carrier")

class Package(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    barcode = db.Column(db.String(100))
    size = db.Column(db.String(20))
    destination = db.Column(db.String(120))
    photo_filename = db.Column(db.String(255))
    scanned_by = db.Column(db.Integer)
    scanned_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route("/")
def home():
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form["email"]).first()
        if user and user.password == request.form["password"]:
            login_user(user)
            return redirect(url_for("dashboard"))
        flash("Invalid login")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        user = User(email=request.form["email"], password=request.form["password"])
        db.session.add(user)
        db.session.commit()
        flash("Account created.")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/dashboard")
@login_required
def dashboard():
    pkgs = Package.query.filter_by(scanned_by=current_user.id).all()
    return render_template("dashboard.html", packages=pkgs)

@app.route("/scan", methods=["GET", "POST"])
@login_required
def scan():
    if request.method == "POST":
        file = request.files.get("photo")
        filename = None
        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        pkg = Package(
            barcode=request.form.get("barcode"),
            size=request.form.get("size"),
            destination=request.form.get("destination"),
            photo_filename=filename,
            scanned_by=current_user.id
        )
        db.session.add(pkg)
        db.session.commit()
        return redirect(url_for("dashboard"))
    return render_template("scan.html")

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
