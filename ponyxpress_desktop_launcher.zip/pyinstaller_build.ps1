
$ErrorActionPreference = "Stop"
pyinstaller --onefile splash.py --name PonyXpressApp
