
from tkinter import Tk, Label
import time
import subprocess

root = Tk()
root.overrideredirect(True)
root.geometry("400x300+500+250")
label = Label(root, text="🚚 PonyXpress", font=("Helvetica", 28))
label.pack(expand=True)
root.after(3000, lambda: [root.destroy(), subprocess.call(["python", "ponyxpress_full_app.py"])])
root.mainloop()
