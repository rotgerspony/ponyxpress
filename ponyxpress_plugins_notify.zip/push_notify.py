
def send_notification(title, body, user_token=None):
    # Stubbed notification logic
    print(f"🔔 Notification: {title} — {body}")
    # Integrate with service like Firebase, OneSignal, or web-push
