PonyXpress — All-in-One Complete Delivery App
=============================================

🚀 Features:
- Role-based auth (carrier, admin)
- Barcode + package scan + photo uploads
- Leaflet GPS map tracing
- Save & replay traces
- Admin dashboard (users, stats, packages)
- CSV export
- Offline support via PWA (manifest + service worker)
- Uploads, trace logging, dashboard analytics

✅ To Run:
1. `pip install -r requirements.txt`
2. `python ponyxpress_full_app.py`
3. Open http://127.0.0.1:5000

Enjoy the full PonyXpress stack!

