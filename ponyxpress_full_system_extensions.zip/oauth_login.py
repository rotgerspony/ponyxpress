
def login_with_google():
    print("Redirecting to Google OAuth...")
    # Redirect user to Google login and handle callback
