
def call_webhook(event):
    print("Webhook triggered:", event)
