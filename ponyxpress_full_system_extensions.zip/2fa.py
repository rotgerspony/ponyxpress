
def send_2fa_code(user):
    print(f"2FA code sent to {user.email}")
    return True
