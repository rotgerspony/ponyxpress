
def trigger_zapier(data):
    print("Zap triggered with", data)
