
def combine_routes(routes):
    combined = []
    for route in routes:
        combined.extend(route)
    return combined
