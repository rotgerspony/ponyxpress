
def suggest_address(term):
    return ["123 Main St", "124 Main St", "125 Main St"]
