
def load_offline_tiles(folder="tiles/"):
    print("Loading offline tiles from", folder)
