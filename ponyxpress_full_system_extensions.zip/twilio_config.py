
def setup_twilio():
    print("Twilio channels configured")
