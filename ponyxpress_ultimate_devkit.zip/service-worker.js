// offline logic
