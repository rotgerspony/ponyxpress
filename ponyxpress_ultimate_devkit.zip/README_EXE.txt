Run: pyinstaller --onefile ponyxpress_full_app.py
