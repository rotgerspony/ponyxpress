Use Kivy, BeeWare, or Flask2APK to compile for Android.
