self.addEventListener("install", event => {
  event.waitUntil(
    caches.open("px-cache").then(cache => {
      return cache.addAll(["/", "/map", "/dashboard", "/static/icon-192.png"]);
    })
  );
});

self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(resp => {
      return resp || fetch(event.request);
    })
  );
});