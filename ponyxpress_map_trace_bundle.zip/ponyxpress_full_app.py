
# ponyxpress_full_app.py with map tracing + stops

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ponyxpress.db'
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(120))
    role = db.Column(db.String(20), default="carrier")

class Stop(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120))
    lat = db.Column(db.Float)
    lng = db.Column(db.Float)
    side = db.Column(db.String(10), default="right")
    user_id = db.Column(db.Integer)

class Trace(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    coords_json = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route("/")
def home():
    return redirect(url_for("map_view"))

@app.route("/map")
@login_required
def map_view():
    stops = Stop.query.filter_by(user_id=current_user.id).all()
    return render_template("map.html", stops=stops)

@app.route("/stops", methods=["POST"])
@login_required
def add_stop():
    data = request.get_json()
    stop = Stop(name=data.get("name"), lat=data.get("lat"), lng=data.get("lng"), side=data.get("side"), user_id=current_user.id)
    db.session.add(stop)
    db.session.commit()
    return jsonify({"status": "ok", "id": stop.id})

@app.route("/trace", methods=["POST"])
@login_required
def save_trace():
    coords = request.get_json().get("coords")
    trace = Trace(coords_json=str(coords), user_id=current_user.id)
    db.session.add(trace)
    db.session.commit()
    return jsonify({"status": "saved"})

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form["email"]).first()
        if user and user.password == request.form["password"]:
            login_user(user)
            return redirect(url_for("map_view"))
        flash("Invalid login")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        user = User(email=request.form["email"], password=request.form["password"])
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("login"))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
