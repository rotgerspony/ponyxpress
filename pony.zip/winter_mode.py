
def apply_winter_mode(app):
    app.config['WINTER_MODE'] = True
    app.jinja_env.globals['theme'] = 'winter'
    print("❄️ Winter mode activated: slower travel times, cold palette")
