
def get_settings():
    return {"map_style": "light", "delivery_rate": 1.25}

def update_settings(new_settings):
    print("Updated settings:", new_settings)
