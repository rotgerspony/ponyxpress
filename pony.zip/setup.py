
from setuptools import setup

setup(
    name='ponyxpress',
    version='1.0',
    py_modules=['ponyxpress_full_app'],
    install_requires=[
        'flask', 'flask-login', 'flask-sqlalchemy', 'flask-wtf',
        'python-dotenv', 'wtforms', 'werkzeug'
    ],
)
