
# Stub: AI route planning or customer assistant bot

def respond_to_prompt(prompt):
    # TODO: integrate OpenAI or local LLM
    return f'I received: {prompt}'
