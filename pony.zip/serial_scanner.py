
import serial

def read_barcode_from_port(port='COM3', baudrate=9600):
    try:
        ser = serial.Serial(port, baudrate, timeout=1)
        print(f"Listening on {port}...")
        while True:
            line = ser.readline().decode('utf-8').strip()
            if line:
                print("Scanned barcode:", line)
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    read_barcode_from_port()
