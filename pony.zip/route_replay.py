
from flask import Blueprint, jsonify, render_template_string
from flask_login import login_required, current_user
from .models import Trace
import json

replay_bp = Blueprint("replay", __name__)

@replay_bp.route("/replay")
@login_required
def replay():
    traces = Trace.query.filter_by(user_id=current_user.id).order_by(Trace.created_at.desc()).all()
    if not traces:
        return "No route data available"
    coords = json.loads(traces[0].coords_json)
    return render_template_string("""<h3>Last Route Replay</h3>
    <ul>{% for c in coords %}<li>{{ c }}</li>{% endfor %}</ul>
    <a href='/dashboard'>Back</a>""", coords=coords)
