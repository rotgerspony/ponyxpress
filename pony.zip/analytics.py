
from flask import Blueprint, render_template_string
from flask_login import login_required
from .models import Package
from datetime import datetime
from collections import Counter

analytics_bp = Blueprint("analytics", __name__)

@analytics_bp.route("/packages/stats")
@login_required
def package_stats():
    all_packages = Package.query.all()
    size_counts = Counter([p.size for p in all_packages])
    return render_template_string("""
        <h2>Package Stats</h2>
        {% for size, count in size_counts.items() %}
          <p>{{ size }}: {{ count }}</p>
        {% endfor %}
        <a href='/dashboard'>Back</a>
    """, size_counts=size_counts)
