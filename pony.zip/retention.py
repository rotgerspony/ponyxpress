
def enforce_data_retention(days=90):
    print(f"Removing data older than {days} days...")
