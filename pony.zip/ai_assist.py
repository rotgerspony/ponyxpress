
def suggest_next_stop(current_lat, current_lng, stops):
    # TODO: implement route optimization algorithm
    return sorted(stops, key=lambda s: abs(s['lat'] - current_lat) + abs(s['lng'] - current_lng))[0]
