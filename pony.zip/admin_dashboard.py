
from flask import Blueprint, render_template_string
from flask_login import login_required
from .models import User, Package, Stop

admin_bp = Blueprint("admin", __name__)

@admin_bp.route("/admin")
@login_required
def admin_panel():
    users = User.query.all()
    packages = Package.query.all()
    stops = Stop.query.all()
    return render_template_string("""
    <h2>Admin Dashboard</h2>
    <p>Total Users: {{ users|length }}</p>
    <p>Total Packages: {{ packages|length }}</p>
    <p>Total Stops: {{ stops|length }}</p>
    <a href='/dashboard'>Back</a>""", users=users, packages=packages, stops=stops)
