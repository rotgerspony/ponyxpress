# PonyXpress

## Setup Instructions
```powershell
.\bootstrap.ps1
```

## Reset Database
```powershell
.\reset-db.ps1
```

## Seed Admin
```powershell
.\seed-demo.ps1
```

Visit http://127.0.0.1:5000
