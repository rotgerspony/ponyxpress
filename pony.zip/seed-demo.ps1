$ErrorActionPreference = "Stop"
. .\venv\Scripts\Activate.ps1
python -c "from ponyxpress_full_app import db, User, app; app.app_context().push();
if not User.query.filter_by(email='admin@example.com').first():
    admin = User(email='admin@example.com', role='admin')
    admin.set_password('admin123')
    db.session.add(admin)
    db.session.commit()
    print('Admin user created.')
else:
    print('Admin user already exists.')"
