
import time
import json
import random

def get_fake_gps():
    return {"lat": 44.725 + random.random()/100, "lng": -94.488 + random.random()/100, "timestamp": time.time()}

def record_gps(path="gps_log.json"):
    logs = []
    for _ in range(10):
        loc = get_fake_gps()
        logs.append(loc)
        print("Logged:", loc)
        time.sleep(2)
    with open(path, "w") as f:
        json.dump(logs, f)

if __name__ == "__main__":
    record_gps()
