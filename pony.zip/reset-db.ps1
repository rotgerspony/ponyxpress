$ErrorActionPreference = "Stop"
. .\venv\Scripts\Activate.ps1
if (Test-Path "ponyxpress.db") {
    Remove-Item "ponyxpress.db" -Force
}
python -c "from ponyxpress_full_app import db, app; app.app_context().push(); db.create_all()"
