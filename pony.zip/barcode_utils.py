
from flask import Blueprint, request, jsonify
from flask_login import login_required
from .models import Package

barcode_bp = Blueprint("barcode", __name__)

@barcode_bp.route("/barcode/check", methods=["POST"])
@login_required
def check_barcode():
    data = request.get_json()
    barcode = data.get("barcode")
    exists = Package.query.filter_by(barcode=barcode).first() is not None
    return jsonify({"exists": exists})

@barcode_bp.route("/barcode/test")
def test_barcode():
    return "<form method='post' action='/barcode/check'>Barcode: <input name='barcode'><button>Check</button></form>"
