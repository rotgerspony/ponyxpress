
import unittest
from ponyxpress_full_app import app, db, User

class AppTestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app = app.test_client()
        with app.app_context():
            db.create_all()

    def test_home_redirects(self):
        res = self.app.get('/')
        self.assertIn(res.status_code, [302, 200])

if __name__ == '__main__':
    unittest.main()
