$ErrorActionPreference = "Stop"
python -m venv .venv
. .\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python ponyxpress_full_app.py
