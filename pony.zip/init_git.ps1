
$ErrorActionPreference = "Stop"

git init
git add .
git commit -m "Initial commit of PonyXpress"
git branch -M main
git remote add origin https://github.com/your-username/ponyxpress.git
git push -u origin main
