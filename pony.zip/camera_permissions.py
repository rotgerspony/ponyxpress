
def check_camera_access():
    print("Checking camera access... granted")
