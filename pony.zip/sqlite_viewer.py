
import sqlite3

def browse_db(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    print("Tables:", tables)
    for tbl in tables:
        print(f"\nContents of {tbl[0]}:")
        for row in cursor.execute(f"SELECT * FROM {tbl[0]} LIMIT 5"):
            print(row)
    conn.close()

if __name__ == "__main__":
    browse_db("ponyxpress.db")
