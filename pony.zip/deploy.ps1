
$ErrorActionPreference = "Stop"

echo "💡 Visit https://dashboard.render.com/ to connect your GitHub repo."
echo "➡️  Add render.yaml to the root of your repo."
echo "✅  Render will auto-detect and deploy the app."
