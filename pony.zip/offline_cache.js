
window.addEventListener('load', () => {
  console.log('PonyXpress ready to cache offline...');
});
