
def sync_to_sheets():
    print("Syncing to Google Sheets")
