
def post_to_slack(msg):
    print("Posting to Slack:", msg)
