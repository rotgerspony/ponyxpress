
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from .models import Trace, db

traces_bp = Blueprint("traces", __name__)

@traces_bp.route("/traces/save", methods=["POST"])
@login_required
def save_trace():
    data = request.get_json()
    coords = data.get("coords")
    if not coords:
        return jsonify({"error": "Missing coords"}), 400
    trace = Trace(user_id=current_user.id, coords_json=json.dumps(coords))
    db.session.add(trace)
    db.session.commit()
    return jsonify({"success": True})

@traces_bp.route("/traces")
@login_required
def get_traces():
    traces = Trace.query.filter_by(user_id=current_user.id).all()
    return jsonify([json.loads(t.coords_json) for t in traces])
