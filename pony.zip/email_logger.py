
import smtplib
from email.message import EmailMessage

def send_log_email(to_email, subject, body, attachment=None):
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = "your@email.com"
    msg['To'] = to_email
    msg.set_content(body)

    if attachment:
        with open(attachment, 'rb') as f:
            msg.add_attachment(f.read(), filename=attachment)

    with smtplib.SMTP('smtp.example.com', 587) as smtp:
        smtp.starttls()
        smtp.login("your@email.com", "password")
        smtp.send_message(msg)

# Example:
# send_log_email("dev@ponyxpress.com", "System Log", "See attached", "gps_log.json")
