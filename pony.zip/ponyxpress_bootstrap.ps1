# ponyxpress_full_app.py
# PonyXpress unified full app with major enhancements

import os
import sys
import csv
import json
from flask import Flask, render_template_string, request, redirect, url_for, flash, jsonify, abort, send_from_directory, Response
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_wtf import FlaskForm
from werkzeug.utils import secure_filename
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
from datetime import datetime

# --------------------------
# Load environment settings
# --------------------------
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv("SECRET_KEY", "dev-key")
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("SQLALCHEMY_DATABASE_URI", "sqlite:///ponyxpress.db")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.getenv("UPLOAD_FOLDER", "uploads")
MAPBOX_TOKEN = os.getenv("MAPBOX_TOKEN", "")
DEBUG_MODE = True
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# --------------------------
# Initialize extensions
# --------------------------
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# --------------------------
# Models
# --------------------------
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="carrier")
    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)

class Stop(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    lat = db.Column(db.Float, nullable=False)
    lng = db.Column(db.Float, nullable=False)
    side = db.Column(db.String(10), nullable=False, default="right")

class Trace(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    coords_json = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

class Package(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    barcode = db.Column(db.String(100), nullable=False)
    size = db.Column(db.String(20))
    destination = db.Column(db.String(120))
    photo_filename = db.Column(db.String(255))
    scanned_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    scanned_at = db.Column(db.DateTime, default=datetime.utcnow)

# --------------------------
# Forms
# --------------------------
class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class RegisterForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Register")

# --------------------------
# Auth + Roles
# --------------------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def admin_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapper

# --------------------------
# Routes
# --------------------------
@app.route("/")
def home():
    return redirect(url_for("dashboard" if current_user.is_authenticated else "login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower()).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for("dashboard"))
        flash("Invalid login")
    return render_template_string("""<form method='post'>{{ form.hidden_tag() }}{{ form.email.label }} {{ form.email }}<br>{{ form.password.label }} {{ form.password }}<br>{{ form.submit }}</form><a href='/register'>Register</a>""", form=form)

@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(email=form.email.data.lower(), role="carrier")
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash("Registered successfully")
        return redirect(url_for("login"))
    return render_template_string("""<form method='post'>{{ form.hidden_tag() }}{{ form.email.label }} {{ form.email }}<br>{{ form.password.label }} {{ form.password }}<br>{{ form.submit }}</form><a href='/login'>Back to login</a>""", form=form)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template_string("""
    <h1>Welcome {{ current_user.email }}</h1>
    <a href='/scan'>📦 Scan Package</a><br>
    <a href='/packages'>📋 View Packages</a><br>
    {% if current_user.role == 'admin' %}
        <a href='/admin'>🛠 Admin</a><br>
    {% endif %}
    <a href='/logout'>Logout</a>
    """)

@app.route("/scan", methods=["GET", "POST"])
@login_required
def scan():
    if request.method == "POST":
        data = request.form
        file = request.files.get("photo")
        filename = None
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
        pkg = Package(
            barcode=data.get("barcode"),
            size=data.get("size"),
            destination=data.get("destination"),
            photo_filename=filename,
            scanned_by=current_user.id
        )
        db.session.add(pkg)
        db.session.commit()
        return redirect(url_for("dashboard"))
    return render_template_string("""<form method='post' enctype='multipart/form-data'>Barcode: <input name='barcode'><br>Size: <select name='size'><option>Too Big</option><option>Too Small</option></select><br>Destination: <input name='destination'><br>Photo: <input type='file' name='photo'><br><button type='submit'>Submit</button></form><a href='/dashboard'>Back</a>""")

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# More views for /packages, /admin, /stats would continue below...

# --------------------------
# Main
# --------------------------
if __name__ == "__main__":
    try:
        with app.app_context():
            db.create_all()
        print("Running PonyXpress on http://127.0.0.1:5000")
        app.run(debug=DEBUG_MODE)
    except Exception as e:
        print("Error:", e)
        sys.exit(1)
