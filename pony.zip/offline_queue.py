
from flask import Blueprint, request, jsonify
from flask_login import login_required
import os, json

offline_bp = Blueprint("offline", __name__)
queue_file = "offline_queue.json"

@offline_bp.route("/offline/queue", methods=["POST"])
@login_required
def queue_package():
    data = request.get_json()
    queue = []
    if os.path.exists(queue_file):
        with open(queue_file) as f:
            queue = json.load(f)
    queue.append(data)
    with open(queue_file, "w") as f:
        json.dump(queue, f)
    return jsonify({"queued": len(queue)})

@offline_bp.route("/offline/flush", methods=["GET"])
@login_required
def flush_queue():
    if not os.path.exists(queue_file):
        return jsonify({"flushed": 0})
    with open(queue_file) as f:
        queue = json.load(f)
    os.remove(queue_file)
    return jsonify({"flushed": len(queue), "data": queue})
