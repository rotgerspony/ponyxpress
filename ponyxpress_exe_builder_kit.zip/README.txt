To create a Windows .EXE for PonyXpress:

1. Install pyinstaller (inside your venv):
   pip install pyinstaller

2. Run this from PowerShell:
   pyinstaller --noconfirm --onefile ponyxpress_full_app.py

3. Your .EXE will be in the /dist folder.
   Double-click to launch the app on port 5000.

Note:
- Make sure templates/, static/, and uploads/ folders are copied beside the .EXE
- Use 'startup.bat' for virtualenv-based run
