PonyXpress Complete SuperBundle

Includes:
- Role-based login (carrier, admin)
- GPS Map Route tracing (/map)
- Package scanning with photo (/scan)
- Admin dashboard (/admin) for user/stop/trace/package management
- PDF + CSV export support
- Uploads + trace replay
- SQLite database config
- Leaflet map integration
- Everything runs locally with Flask

Start with:
> python ponyxpress_full_app.py

You'll need:
> pip install flask flask_sqlalchemy flask_login werkzeug
